import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-summary',
  templateUrl: './event-summary.page.html',
  styleUrls: ['./event-summary.page.scss'],
})
export class EventSummaryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
